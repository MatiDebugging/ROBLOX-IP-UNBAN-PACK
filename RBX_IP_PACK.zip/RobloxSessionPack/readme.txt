!!!
rs.dll is the roblox server.
do not edit it or the roblox service in SessionEditor will not work.
(but it may be saved in the cloud)